Team Members:
1)Ajay Venkatesha (1001861936)
2)Sayali Dilip Deshmukh(1001966628)

======================================

Requirements:
PyCharm Community Edition/Visual Studio Code
======================================

Programming Language: 
Python3

======================================

Execution and Instructions:

1. There are 2 folders computation-server and file-server

2. In the Computation server folder there is a client and server folder and the main file for running addition and sorting operations
For running the main file Open Terminal run python ComputationServerMain.py

3. In the Computation server folder, open the client there is ClientASYN, and ClientSYN whereas in Server, there is the server that supports synchronised and A synchronised 
solution

4. In the file-server folder there is a client and server folder and the main file 
For running the main file Open Terminal run python FileServerMain.py

5. In the file-server folder, the addition of a data folder in client and server.

6. There is also FileOperationsDownload.py for file download opeartion regarding files.
To perform the download opeation execute python FileOperationsDownload.py
