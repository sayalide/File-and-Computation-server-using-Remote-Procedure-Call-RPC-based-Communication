import threading
from server.server import server_register_function
from client.client import ClientFileChecker

if __name__ == "__main__":
    try:
        # server.serve_forever()
        t1 = threading.Thread(target=server_register_function)
        t1.start()
        print("##############################")
        print('\t  server is running')
        t2 = threading.Thread(target=ClientFileChecker)
        t2.start()
        print('\t  Client is running')
        print("##############################")
    except:
        print('exiting')

