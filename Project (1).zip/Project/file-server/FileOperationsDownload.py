import os
import xmlrpc.client
from client.client import CDD, proxy

# Please choose the following operations by uncommeting the operation that you want to perform


if __name__ == "__main__":
    FileName = 'cat.jpg'

    print('Server is up and running')
    # proxy.delete(FileName)
    # print('after deleting file')

    # with open(os.path.join(CDD, FileName), 'rb') as file:
    #    proxy.upload(FileName, xmlrpc.client.Binary(file.read()))
    #    print('after uploading file')

    with open(os.path.join(CDD, FileName), 'wb') as file:
        binary_data = proxy.download(FileName)
        file.write(binary_data.data)
        print('after downloading file')

    # proxy.rename('cat.jpg', 'CuteCat.jpg')
    # print('File has been renamed')



