import os
from . import data
from socketserver import ThreadingMixIn
from xmlrpc.server import SimpleXMLRPCServer
import xmlrpc.client


SDD = os.path.abspath(data.__file__)
SDD = os.path.dirname(SDD)
port = 8024

print(f"The file location for the server is  {SDD}")

class MTXMLSERVER(ThreadingMixIn, SimpleXMLRPCServer):
    pass


def delete(FN: str) -> None:
    location = os.path.join(SDD, FN)
    os.remove(location)
    print(f"The file has been successfully deleted from the location {location}")
    return

def download(FN: str):
    location = os.path.join(SDD, FN)
    with open(location, 'rb') as file:
        return xmlrpc.client.Binary(file.read())

def rename(curr_name: str, new_name: str) -> None:
    CL = os.path.join(SDD, curr_name)
    NL = os.path.join(SDD, new_name)
    os.rename(CL, NL)
    return

def upload(FN: str, FD) -> None:
    location = os.path.join(SDD, FN)
    with open(location, 'wb') as file:
        file.write(FD.data)
    return


def server_register_function():
    with MTXMLSERVER(('localhost', port), allow_none=True) as x:
        x.register_introspection_functions()

        x.register_function(download)
        x.register_function(upload)
        x.register_function(delete)
        x.register_function(rename)
        print(f"The server is serving on port {port}")

        x.serve_forever()
    return
