import os
import time
import xmlrpc.client
from . import data

port = 8024
CDD = os.path.abspath(data.__file__)
CDD = os.path.dirname(CDD)
proxy = xmlrpc.client.ServerProxy(f"http://localhost:{port}")
print(f"client is storing the files in {CDD}")


def isfile(filename):
    return os.path.isfile(os.path.join(CDD, filename))

def GMF(files, FileChangeTime, PriorTimeCheck):
    modified_files = []
    for f in files:
        if(FileChangeTime[f] >= PriorTimeCheck):
            modified_files.append(f)
    return modified_files


def UMF(files): #upload modified files to the server
    for f in files:
        UF(f)
    return


def get_files():
    files = [f for f in os.listdir(CDD) if (isfile(f) and f != '__init__.py')]
    return files

def CheckIffileisModified(files, FileChangeTime):
    for f in files:
        filepath = os.path.join(CDD, f)
        FileChangeTime[f] = os.path.getmtime(filepath)
    return


def get_deleted_files(files, FileChangeTime):
    deleted_files = []
    for f in FileChangeTime:
        if f not in files:
            deleted_files.append(f)
    return deleted_files

def UF(filename):
    try:
        with open(os.path.join(CDD, filename), 'rb') as f:
            proxy.UPLOAD(filename, xmlrpc.client.Binary(f.read()))
    except:
        print(f"uploading failed for the {filename}")
    return


def DeleteFiles(f, FileChangeTime):
    try:
        proxy.DELETE(f)
        del FileChangeTime[f]
    except:
        print(f"deleting failed for {f}")
    return

def DeleteFilesFromServer(files, FileChangeTime):
    for f in files:
        DeleteFiles(f, FileChangeTime)
    return

def check_files(PriorTimeCheck, FileChangeTime):
    files = get_files()
    CheckIffileisModified(files, FileChangeTime)

    modified_files = GMF(files, FileChangeTime, PriorTimeCheck)
    UMF(modified_files)

    deleted_files = get_deleted_files(files, FileChangeTime)
    DeleteFilesFromServer(deleted_files, FileChangeTime)
    return

def CopyAlllFiles():
    files = get_files()
    UMF(files)
    return;

def ClientFileChecker():
    CopyAlllFiles()
    FileChangeTime = {}
    PriorTimeCheck = time.time()
    while True:
        print('started file Checker')
        CheckStartTime = time.time()
        check_files(PriorTimeCheck, FileChangeTime)
        PriorTimeCheck = CheckStartTime
        del CheckStartTime
        time.sleep(7)
    return
