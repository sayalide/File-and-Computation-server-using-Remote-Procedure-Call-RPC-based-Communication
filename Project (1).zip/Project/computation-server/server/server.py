from xmlrpc.server import SimpleXMLRPCServer
from socketserver import ThreadingMixIn
import sqlite3
import json
import time
import threading

SynPort = 8024
ASynPort = 8025

Session = sqlite3.connect('DataBase.db')
SessionCursor = Session.cursor()
SessionCursor.execute('''CREATE TABLE IF NOT EXISTS added_data(X text, Y text, result text)''')
SessionCursor.execute('''CREATE TABLE IF NOT EXISTS sorted_data(A text, result text)''')
Session.commit()
SessionCursor.close()
Session.close()


class MTSXMLRPCS(ThreadingMixIn, SimpleXMLRPCServer):
    pass

def add(X, Y):
    return X + Y

def sort(A):
    A.sort()
    return A


def AsynSort(A):
    original = json.loads(json.dumps(A))
    time.sleep(1)
    A.sort()
    Session = sqlite3.connect('DataBase.db')
    SessionCursor = Session.cursor()
    SessionCursor.execute(f"INSERT INTO sorted_data VALUES ('{json.dumps(original)}', '{json.dumps(A)}')")
    Session.commit()
    SessionCursor.close()
    Session.close()
    return


def AsynSortThread(A):
    TempThread=threading.Thread(target=AsynSort, args=(A,))
    TempThread.start()
    return


def AsynAdd(X, Y):
    time.sleep(1)
    sum = X + Y
    Session = sqlite3.connect('DataBase.db')
    SessionCursor = Session.cursor()
    SessionCursor.execute(f"INSERT INTO added_data VALUES ('{X}','{Y}','{sum}')")
    Session.commit()
    SessionCursor.close()
    Session.close()
    return


def AsynAddThread(X, Y):
    TempThread=threading.Thread(target=AsynAdd,args=(X, Y))
    TempThread.start()
    return

def AsynServerStarter():
    with MTSXMLRPCS(('localhost', ASynPort), allow_none=True) as S:
        S.register_introspection_functions()
        S.register_function(AsynAddThread, 'add')
        S.register_function(AsynSortThread, 'sort')
        print(f"asynchronous Server is serving on port {ASynPort}")
        S.serve_forever()
    return

def SynServerStarter():
    with MTSXMLRPCS(('localhost', SynPort),allow_none=True) as S:
        S.register_introspection_functions()
        S.register_function(add)
        S.register_function(sort)
        print(f"synchronous Server is serving on port {SynPort}")
        S.serve_forever()
    return
