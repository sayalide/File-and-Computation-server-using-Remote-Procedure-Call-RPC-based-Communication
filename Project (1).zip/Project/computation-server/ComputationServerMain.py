import threading
from server.server import SynServerStarter, AsynServerStarter
from client import ClientSYN
from client import ClientASYN
import sqlite3
import time

if __name__ == "__main__":
    try:
        t1 = threading.Thread(target=SynServerStarter)
        t1.start()
        print('synchronous server is running')
        print(f"synchronous add 8,7: {ClientSYN.SyncAdd(8, 7)}")
        print(f"synchronous sort [4, 7, 1, 8, 2, 3, 0, 9]: {ClientSYN.SynSort([4, 7, 1, 8, 2, 3, 0, 9])}")

        t2 = threading.Thread(target=AsynServerStarter)
        t2.start()
        print("asynchronous server is running")
        print(f"asynchronous add 8,7: {ClientASYN.AsynAdd(8, 7)}")
        print(f"asynchronous sort [4, 7, 1, 8, 2, 3, 0, 9]: {ClientASYN.AsynSort([4, 7, 1, 8, 2, 3, 0, 9])}")

        con = sqlite3.connect('DataBase.db')
        cur = con.cursor()
        time.sleep(5)
        added_data = cur.execute("SELECT * FROM added_data")
        print(added_data.fetchall())
        sorted_data = cur.execute("SELECT * FROM sorted_data")
        print(sorted_data.fetchall())
        con.commit()

        cur.close()
        con.close()

    except Exception as err:
        print('An Exception was encounter and the error is: ', err)



