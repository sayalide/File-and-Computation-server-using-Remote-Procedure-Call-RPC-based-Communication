
import xmlrpc.client


sync_port = 8024
sync_server_uri = f"http://localhost:{sync_port}"
sync_proxy = xmlrpc.client.ServerProxy(sync_server_uri)

def SyncAdd(x,y):
    return sync_proxy.add(x,y)

def SynSort(x):
    return sync_proxy.sort(x)
