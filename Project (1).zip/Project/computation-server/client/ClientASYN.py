import xmlrpc.client

async_port = 8025
async_server_uri = f"http://localhost:{async_port}"
async_proxy = xmlrpc.client.ServerProxy(async_server_uri)

def AsynAdd(x,y):
    try:
        async_proxy.add(x,y)
    except Exception as err:
        print(err)   
    return 

def AsynSort(x):
    try:
        async_proxy.sort(x)
    except Exception as err:
        print(err)    
    return
